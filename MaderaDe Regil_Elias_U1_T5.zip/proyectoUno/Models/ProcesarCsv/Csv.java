package proyectoUno.Models.ProcesarCsv;

public class Csv {
    private String[] encabezado;
    private String[][] entradas;
    public String[] GetEncabezado(){
        return this.encabezado;
    }
    public void SetEncabezado(String[] encabezado){
        this.encabezado = encabezado;
    }
    public String[][] GetEntradas(){
        return this.entradas;
    }
    public void SetEntradas(String[][] entradas){
        this.entradas = entradas;
    }
}
