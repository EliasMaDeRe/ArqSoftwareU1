package proyectoUno.Models.ProcesarTemplate;

public class Identificador {
    private String identificador;
    private int numeroDePalabraEnFila;
    private int fila;
    public int getNumeroDePalabraEnFila(){
        return this.numeroDePalabraEnFila;
    }
    public void setNumeroDePalabraEnFila(int numeroDePalabraEnFila){
        this.numeroDePalabraEnFila = numeroDePalabraEnFila;
    }
    public int getFila(){
        return this.fila;
    }
    public void setFila(int fila){
        this.fila = fila;
    }
    public String GetIdentificador(){
        return this.identificador;
    }
    public void SetIdentificador(String identificador){
        this.identificador = identificador;
    }
}
