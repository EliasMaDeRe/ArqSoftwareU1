package proyectoUno.Models.ProcesarTemplate;

public class Template {
    private Identificador[] identificadores;
    private String[] lineasDeContenidoDeTemplate;
    public String[] getLineasDeContenidoDeTemplate(){
        return this.lineasDeContenidoDeTemplate;
    }
    public void setLineasDeContenidoDeTemplate(String[] lineasDeContenidoDeTemplate){
        this.lineasDeContenidoDeTemplate = lineasDeContenidoDeTemplate;
    }
    public Identificador[] getIdentificadores(){
        return this.identificadores;
    }
    public void setIdentificadores(Identificador[] identificadores){
        this.identificadores = identificadores;
    }
}
