package proyectoUno.Models.LeerArchivo;

public class Archivo {
    private String[] lineasDeTextoDeArchivo;
    public String[] ObtenerLineasDeTextoDeArchivo(){
        return this.lineasDeTextoDeArchivo;
    }
    public void AgregarLineasDeTextoDeArchivo(String[] lineasDeTextoDeArchivo){
        this.lineasDeTextoDeArchivo = lineasDeTextoDeArchivo;
    }
}
