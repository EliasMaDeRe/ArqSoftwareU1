package proyectoUno.src.LeerArchivo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import proyectoUno.Models.LeerArchivo.*;

public class LeerArchivoControlador {

    private Archivo nuevoArchivoDeTexto(String rutaDeArchivo){

        File file = new File(rutaDeArchivo);

        String[] lineasDeTextoDeArchivo;
        lineasDeTextoDeArchivo = new String[10];

        try {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                int i = 0;
                while ((line = br.readLine()) != null) {
                    lineasDeTextoDeArchivo[i] = line;
                    ++i;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Archivo archivo = new Archivo();
        archivo.AgregarLineasDeTextoDeArchivo(lineasDeTextoDeArchivo);

        return archivo;
        
    }
    public Archivo LeerTemplateDeArchivoDeTexto(String rutaDeArchivo){
        Archivo archivo = nuevoArchivoDeTexto(rutaDeArchivo);
        return archivo;
    }
    public Archivo LeerCsvDeArchivoCsv(String rutaDeArchivo){
        Archivo archivo = nuevoArchivoDeTexto(rutaDeArchivo);
        return archivo;
    }
}

