package proyectoUno.src.LeerArchivo;

import proyectoUno.Models.LeerArchivo.*;

public class LeerArchivoHandler {
    private LeerArchivoControlador controlador;
    public LeerArchivoHandler(){
        this.controlador = new LeerArchivoControlador();
    }
    public Archivo LeerTemplateDeArchivoDeTexto(String rutaDeArchivo){
        return controlador.LeerTemplateDeArchivoDeTexto(rutaDeArchivo);
    }
    public Archivo LeerCsvDeArchivoCsv(String rutaDeArchivo){
        return controlador.LeerCsvDeArchivoCsv(rutaDeArchivo);
    }
}
