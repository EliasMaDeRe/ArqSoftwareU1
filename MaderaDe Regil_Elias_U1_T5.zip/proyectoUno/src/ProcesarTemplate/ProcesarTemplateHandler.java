package proyectoUno.src.ProcesarTemplate;

import proyectoUno.Models.ProcesarTemplate.Identificador;
import proyectoUno.Models.ProcesarTemplate.Template;

public class ProcesarTemplateHandler {
    private ProcesarTemplateControlador controlador;
    public ProcesarTemplateHandler(){
        this.controlador = new ProcesarTemplateControlador();
    }
    public Identificador[] ObtenerIdentificadoresTemplate(String rutaArchivo){
        return controlador.ObtenerIdentificadoresTemplate(rutaArchivo);
    }
    public Template ObtenerTemplate(String rutaArchivo){
        return controlador.ObtenerTemplate(rutaArchivo);
    }
}
