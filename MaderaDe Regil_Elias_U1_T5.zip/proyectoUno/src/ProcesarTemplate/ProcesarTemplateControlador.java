package proyectoUno.src.ProcesarTemplate;

import proyectoUno.Models.LeerArchivo.Archivo;
import proyectoUno.Models.ProcesarTemplate.Identificador;
import proyectoUno.Models.ProcesarTemplate.Template;
import proyectoUno.src.LeerArchivo.LeerArchivoControlador;

public class ProcesarTemplateControlador {
    private LeerArchivoControlador leerArchivoControlador;
    public ProcesarTemplateControlador(){
        leerArchivoControlador = new LeerArchivoControlador();
    }
    public Identificador[] ObtenerIdentificadoresTemplate(String rutaArchivo){
        Archivo archivo = leerArchivoControlador.LeerTemplateDeArchivoDeTexto(rutaArchivo);
        Template template = ProcesarTemplateMapper.ArchivoATemplate(archivo);
        return template.getIdentificadores();
    }
    public Template ObtenerTemplate(String rutaArchivo){
        Archivo archivo = leerArchivoControlador.LeerTemplateDeArchivoDeTexto(rutaArchivo);
        return ProcesarTemplateMapper.ArchivoATemplate(archivo);
    }
}
