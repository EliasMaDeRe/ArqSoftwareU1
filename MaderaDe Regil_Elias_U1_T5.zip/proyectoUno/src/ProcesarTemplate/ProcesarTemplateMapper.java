package proyectoUno.src.ProcesarTemplate;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import proyectoUno.Models.LeerArchivo.Archivo;
import proyectoUno.Models.ProcesarTemplate.Identificador;
import proyectoUno.Models.ProcesarTemplate.Template;

public class ProcesarTemplateMapper {
        public static Template ArchivoATemplate(Archivo archivo){
        if(archivo == null) return null;
        Template template = new Template();
        template.setIdentificadores(getIdentificadoresFromArchivo(archivo));
        template.setLineasDeContenidoDeTemplate(archivo.ObtenerLineasDeTextoDeArchivo());
        return template;
    }
        private static Identificador[] getIdentificadoresFromArchivo(Archivo archivo){
        Identificador[] identificadores = new Identificador[10];
        int k = 0;
        for(int i = 0; i < archivo.ObtenerLineasDeTextoDeArchivo().length; ++i){
            Identificador[] indetificadoresDeLinea = getIdentificadoresFromString(archivo.ObtenerLineasDeTextoDeArchivo()[i]);
            for(int j = 0; j < indetificadoresDeLinea.length; ++j){
                if(indetificadoresDeLinea[j] != null){
                    Identificador identificador = new Identificador();
                    identificador.SetIdentificador(indetificadoresDeLinea[j].GetIdentificador());
                    identificador.setFila(i);
                    identificador.setNumeroDePalabraEnFila(archivo.ObtenerLineasDeTextoDeArchivo()[i].indexOf(identificador.GetIdentificador()));
                    identificadores[k++] = identificador;
                }
            }
        }
        return identificadores;
    }
        private static Identificador[] getIdentificadoresFromString(String string){
        
        Identificador[] identificadores = new Identificador[10];
        int i = 0;
        if(string != null){
            Matcher m = Pattern.compile("\\<(.*?)\\>").matcher(string);
            while (m.find()) {
                if(m.group(1).isBlank()) continue;
                Identificador identificador = new Identificador();
                identificador.SetIdentificador(m.group(1));
                identificadores[i++] = identificador;
            }
        } 
        return identificadores;
    }
}
