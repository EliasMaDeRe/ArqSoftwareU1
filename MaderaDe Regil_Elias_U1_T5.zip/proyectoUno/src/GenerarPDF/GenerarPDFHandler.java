package proyectoUno.src.GenerarPDF;


public class GenerarPDFHandler {
    private GenerarPDFControlador controlador;
    public GenerarPDFHandler(){
        this.controlador = new GenerarPDFControlador();
    }
    public Error ValidarInformacion(String rutaTemplate, String rutaCsv){
        return controlador.ValidarInformacion(rutaTemplate,rutaCsv);
    }
    public Error GenerarPDF(String rutaTemplate, String rutaCsv){
        return controlador.GenerarPDF(rutaTemplate,rutaCsv);
    }
}
