package proyectoUno.src.GenerarPDF;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import proyectoUno.Models.ProcesarTemplate.Identificador;
import proyectoUno.Models.ProcesarTemplate.Template;
import proyectoUno.src.ProcesarCsv.ProcesarCsvControlador;
import proyectoUno.src.ProcesarTemplate.ProcesarTemplateControlador;

public class GenerarPDFControlador {
    private ProcesarTemplateControlador procesarTemplateControlador;
    private ProcesarCsvControlador procesarCsvControlador;
    private final String RUTA_REPORTE = "C:\\Users\\El\u00EDas\\Desktop\\Proyectos\\ArquitecturaSoftware\\proyectoUno\\src\\Main\\reporte.pdf";
    private final String IDENTIFICADOR_EN_TEMPLATE_NO_SE_ENCUENTRA_EN_CSV = "Identificador presente en Template no se encuentra en CSV";
    private final String NO_HAY_IDENTIFICADORES_EN_TEMPLATE = "No hay identificadores en el template";
    private final String CSV_NO_CONTIENE_DATOS = "El Csv no contiene datos";
    public GenerarPDFControlador(){
        procesarCsvControlador = new ProcesarCsvControlador();
        procesarTemplateControlador = new ProcesarTemplateControlador();
    }
    public Error ValidarInformacion(String rutaTemplate, String rutaCsv){
        Identificador[] identificadoresDeTemplate = procesarTemplateControlador.ObtenerIdentificadoresTemplate(rutaTemplate);

        if(identificadoresDeTemplate[0] == null) return new Error(NO_HAY_IDENTIFICADORES_EN_TEMPLATE);

        for(int i = 0; i < identificadoresDeTemplate.length && identificadoresDeTemplate[i] != null; ++i){
            if(!estaIdentificadorPresenteEnIdentificadoresCsv(identificadoresDeTemplate[i], rutaCsv)){
                return new Error(IDENTIFICADOR_EN_TEMPLATE_NO_SE_ENCUENTRA_EN_CSV);
            }
        }

        HashMap<String,ArrayList<String>> datosCsv = procesarCsvControlador.ObtenerDatosCsv(rutaCsv);
        if(datosCsv.get(identificadoresDeTemplate[0].GetIdentificador()) == null || datosCsv.get(identificadoresDeTemplate[0].GetIdentificador()).size() == 0)
            return new Error(CSV_NO_CONTIENE_DATOS);

        return null;
    }
    public Error GenerarPDF(String rutaTemplate, String rutaCsv){

        Error err = ValidarInformacion(rutaTemplate,rutaCsv);
        if( err != null)
            return err;

        Template template = procesarTemplateControlador.ObtenerTemplate(rutaTemplate);
        HashMap<String,ArrayList<String>> datosCsv = procesarCsvControlador.ObtenerDatosCsv(rutaCsv);

        PDDocument document = generarPDF();
        for(int entrada = 0; entrada < datosCsv.get(template.getIdentificadores()[0].GetIdentificador()).size(); ++entrada){
            template = procesarTemplateControlador.ObtenerTemplate(rutaTemplate);
            for(int i = 0; i < template.getIdentificadores().length && template.getIdentificadores()[i] != null; ++i){
                    int numeroDeLinea = template.getIdentificadores()[i].getFila();
                    if(numeroDeLinea < template.getLineasDeContenidoDeTemplate().length &&
                    template.getLineasDeContenidoDeTemplate()[numeroDeLinea] != null){
                        String stringAnadido = "<"+template.getIdentificadores()[i].GetIdentificador()+">";
                        template.getLineasDeContenidoDeTemplate()[numeroDeLinea] =
                            template.getLineasDeContenidoDeTemplate()[numeroDeLinea].replace(stringAnadido, datosCsv.get(template.getIdentificadores()[i].GetIdentificador()).get(entrada));
                    }
            }
            anadirPaginaAPDF(document, template);
            
        }
        guardarPDF(document);
        cerrarPDF(document);
        return null;        
    }
    private Error cerrarPDF(PDDocument document){
        try{
            document.close();
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
        return null;
    }
    private Error guardarPDF(PDDocument document){
        try{
            document.save(RUTA_REPORTE);
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
        return null;
    }
    private Error anadirPaginaAPDF(PDDocument document, Template template){
        PDPage pagina = new PDPage();
        try{
            PDPageContentStream contentStream = new PDPageContentStream(document,pagina);
            contentStream.beginText();
            contentStream.newLineAtOffset(25, 500);
            contentStream.setFont(PDType1Font.TIMES_ROMAN,14);
            contentStream.setLeading(14.5f);
            for(int i = 0; i < template.getLineasDeContenidoDeTemplate().length && template.getLineasDeContenidoDeTemplate()[i] != null; ++i){
                contentStream.showText(template.getLineasDeContenidoDeTemplate()[i]);
                contentStream.newLine();
            }
            contentStream.endText();
            contentStream.close();

        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
        document.addPage(pagina);
        return null;
    }
    private PDDocument generarPDF(){
        PDDocument document = new PDDocument();
        guardarPDF(document);
        return document;
    }
    private boolean estaIdentificadorPresenteEnIdentificadoresCsv(Identificador identificador, String rutaCsv){
        String[] identificadoresCsv = procesarCsvControlador.ObtenerIdentificadoresCsv(rutaCsv);
        for(int i = 0; i < identificadoresCsv.length; ++i){
            if(identificador.GetIdentificador().equals(identificadoresCsv[i])){
                return true;
            }
        }
        return false;
    }
}
