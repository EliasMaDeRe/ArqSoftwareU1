package proyectoUno.src.ProcesarCsv;

import proyectoUno.Models.LeerArchivo.Archivo;
import proyectoUno.Models.ProcesarCsv.Csv;

public class ProcesarCsvMapper {

    public static Csv ArchivoACsv(Archivo archivo){
        if(archivo == null) return null;
        Csv csv = new Csv();
        csv.SetEncabezado(getEncabezadoFromArchivo(archivo));
        csv.SetEntradas(getEntradasFromArchivo(csv,archivo));
        return csv;
    }
    private static String[][] getEntradasFromArchivo(Csv csv, Archivo archivo){
        String[][] entradas = new String[10][10];
        for(int i = 1; i < archivo.ObtenerLineasDeTextoDeArchivo().length && archivo.ObtenerLineasDeTextoDeArchivo()[i] != null; ++i){
            String[] entradasDeLineas = archivo.ObtenerLineasDeTextoDeArchivo()[i].split("[,]",0);
            for(int j = 0; j < entradasDeLineas.length; ++j){
                entradas[i-1][j] = entradasDeLineas[j];
            }
        }
        return entradas;
    }
    private static String[] getEncabezadoFromArchivo(Archivo archivo){
        String[] encabezado = new String[10];
        if(archivo.ObtenerLineasDeTextoDeArchivo()[0] != null){
            int j = 0;
            String[] encabezados = archivo.ObtenerLineasDeTextoDeArchivo()[0].split("[,]", 0);
            for(int i = 0; i < encabezados.length; ++i){
                encabezado[j++] = encabezados[i];
            }
        }
        return encabezado;
    }
}
