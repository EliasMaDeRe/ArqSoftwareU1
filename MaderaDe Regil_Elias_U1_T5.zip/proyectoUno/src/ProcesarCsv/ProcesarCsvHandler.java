package proyectoUno.src.ProcesarCsv;

import java.util.ArrayList;
import java.util.HashMap;


public class ProcesarCsvHandler {
    private ProcesarCsvControlador controlador;
    public ProcesarCsvHandler(){
        this.controlador = new ProcesarCsvControlador();
    }
    public String[] ObtenerIdentificadoresCsv(String rutaArchivo){
        return controlador.ObtenerIdentificadoresCsv(rutaArchivo);
    }
    public HashMap<String,ArrayList<String>> ObtenerDatosCsv(String rutaArchivo){
        return controlador.ObtenerDatosCsv(rutaArchivo);
    }
}
