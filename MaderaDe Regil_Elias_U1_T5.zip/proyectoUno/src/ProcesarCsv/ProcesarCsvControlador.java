package proyectoUno.src.ProcesarCsv;

import java.util.ArrayList;
import java.util.HashMap;

import proyectoUno.Models.LeerArchivo.Archivo;
import proyectoUno.Models.ProcesarCsv.Csv;
import proyectoUno.src.LeerArchivo.LeerArchivoControlador;

public class ProcesarCsvControlador {
    private LeerArchivoControlador leerArchivoControlador;
    public ProcesarCsvControlador(){
        leerArchivoControlador = new LeerArchivoControlador();
    }
    public String[] ObtenerIdentificadoresCsv(String rutaArchivo){
        Archivo archivo = leerArchivoControlador.LeerCsvDeArchivoCsv(rutaArchivo);
        Csv csv = ProcesarCsvMapper.ArchivoACsv(archivo);
        return csv.GetEncabezado();
    }
    public HashMap<String,ArrayList<String>> ObtenerDatosCsv(String rutaArchivo){
        Archivo archivo = leerArchivoControlador.LeerCsvDeArchivoCsv(rutaArchivo);
        Csv csv = ProcesarCsvMapper.ArchivoACsv(archivo);
        HashMap<String,ArrayList<String>> datosCsv = new HashMap<String,ArrayList<String>>();
        for(int i = 0; i < csv.GetEntradas().length && csv.GetEntradas()[i] != null; ++i){
            for(int j = 0; j < csv.GetEntradas()[i].length && csv.GetEntradas()[i][j] != null; ++j){
                if(datosCsv.get(csv.GetEncabezado()[j]) == null) datosCsv.put(csv.GetEncabezado()[j], new ArrayList<String>());
                datosCsv.get(csv.GetEncabezado()[j]).add(csv.GetEntradas()[i][j]);
            }
        }
        return datosCsv;
    }
}
