package proyectoUno.src.Main;

import proyectoUno.src.GenerarPDF.GenerarPDFHandler;

public class main {
    public static void main(String[] args) {
        GenerarPDFHandler generarPDFHandler = new GenerarPDFHandler();
        Error err = generarPDFHandler.GenerarPDF("C:\\Users\\Elías\\Desktop\\Proyectos\\ArquitecturaSoftware\\proyectoUno\\src\\Main\\template.txt", "C:\\Users\\Elías\\Desktop\\Proyectos\\ArquitecturaSoftware\\proyectoUno\\src\\Main\\csv.csv");
        if(err != null){
            err.printStackTrace();
        }
    }
}